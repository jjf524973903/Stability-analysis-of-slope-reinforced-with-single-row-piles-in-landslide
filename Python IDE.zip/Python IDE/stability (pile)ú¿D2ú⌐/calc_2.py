import math
import sympy
from calc_1 import Calck
γ = 18.5 #土层参数
c = 15 #黏聚力
phi = 18.8/180*math.pi #内摩擦 θ
b = 0.51 #土条弧长
a = 30*math.pi/180
D_POS ={'x':0,'y':0} #坡脚D为坐标原点
D = 2 #桩直径
D2 = 6 #桩间距
D1 = 4 #桩净距
L1 = 7 #滑面之上桩深
L2 = 13 #滑面之下桩深
h = 30 #坡高
pi = math.pi
Nphi = math.pow(math.tan(math.pi/4+phi/2),2)
class Calc2:
    @staticmethod
    def calc_Q(Thetai,z): #计算上部滑坡推力Q0。
        li=b/math.cos(Thetai)
        Aexp1 = c*D2*math.pow(D2/D1,math.pow(Nphi,1/2)*math.tan(phi)+Nphi-1)
        Aexp2 = 1/(Nphi*math.tan(phi))*(math.exp((D2-D1)/D1*Nphi*math.tan(phi)*math.tan(math.pi/8+phi/4))-2*math.sqrt(Nphi)*math.tan(phi)-1)
        Aexp3 = (2*math.tan(phi)+2*math.sqrt(Nphi)+math.pow(Nphi,-1/2))/(math.sqrt(Nphi)*math.tan(phi)+Nphi-1)
        A = Aexp1*(Aexp2+Aexp3)
        B = -c*(D2*(2*math.tan(phi)+2*math.sqrt(Nphi)+math.pow(Nphi,-1/2))/(math.sqrt(Nphi)*math.tan(phi)+Nphi-1)-2*D1*math.pow(Nphi,-1/2))
        Cexp1 = D2*math.pow(D2/D1,math.sqrt(Nphi)*math.tan(phi)+Nphi-1)
        Cexp2 = math.exp((D2-D1)/D1*Nphi*math.tan(phi)*math.tan(math.pi/8+phi/4))
        C = γ*z/Nphi*(Cexp1*Cexp2-D1)
        q = A+B+C
        x=sympy.symbols('z')
        Q = sympy.integrate(q,(x,0,L1))
        return Q
        
    @staticmethod
    def main(): #确定支护桩转动中心点位置z0。
        d = 0
        zc= D*(8.5-9*math.log10(8-d/D))#D*(8.5-10*math.log(8-d/D,10))
        ψ = 0.5
        delta = 1/math.sin(ψ)
        print("zc=",zc)
        Npu=math.pi+2*delta+2*math.cos(delta)+4*(math.cos(delta/2)+math.sin(delta/2))
        lbd=0.55-0.15*ψ # λ
        Npo = 2+1.5*ψ
       
        ua = 1-math.sin(a)*(1+math.sin(a))/2
        print("Npo=",Npo,"\nNpu=",Npu,"\nλ=",lbd)
        S1 = γ*D*(Npu-Npo)*math.tan(phi)/lbd
        S2 = D/lbd+c/(γ*math.tan(phi))
        S3 = D/(lbd*ua)+c/(γ*math.tan(phi))
        E = 1-2*math.pow(1-(D2/D)/(2*D2/D*math.tan(phi)+1),2)
        print("\nS1=",S1,"\nS2=",S2,"\nS3=",S3,"\nE=",E,"\nua=",ua)
        
        n1 = 2*γ*Npu*math.tan(phi)+lbd*S1/D*(lbd*(zc+S2)/D-2)*math.exp(-lbd*zc/D)+lbd*S1/D*(lbd*ua/D-2)
        n2 = 2*Npu*(γ*math.tan(phi)+c)-S1*(1-lbd/D*(zc+S2))*math.exp(-lbd*zc/D)-S1/ua*(1-lbd*ua/D*(zc+S3))
     
        z_range= {'min':-5,'max':15}
        z = z_range['min']
        total_res = []
        
        Qg = Calc2.calc_Q(phi,7)
        print("Qg=",Qg)
        n3 = Npu*(γ*math.tan(phi)*(zc**2-L2**2/2)+2*c*zc-c*L2)+S1*math.exp(-lbd*zc/D)*(2*zc+S2-L2)-Qg/(E*D)-S1*S2
        print("\nn1=",n1,"\nn2=",n2,"\nn3=",n3)
        tempresult = {}
        
        if (n2**2-4*n1*n3)>0:
            Z0 = (2*zc*n1-n2+math.sqrt(n2**2-4*n1*n3))/(2*n1)
        else:
            return
        minK = {}
        if L2>Z0:
            calcK=Calck()
            minK=calcK.random_r_qp({'fai':phi,'c':c},False,False,{'r':13.751,'p':-0.920,'q':13.720},True)
            print("mini k=",minK['log'])
            if minK['k']<1:
               print("终止，最小k值不满足大于1")
               return
        else:
             print("终止",L2<=Z0)
        
        if Z0<zc:
           print("终止，Z0<zc")
           return
            
        while z < z_range['max']:
             print("z=",z,"\nz0=",Z0)
             Psu = Calc2.calc_Psu(z,zc,Npu,Npo,ua,Z0,lbd)
             print ("Psu=",Psu)
             CALC_K=Calc()
             karr = CALC_K.random_r_qp({'fai':phi,'c':c},False,False,{'r':13.751,'p':-0.920,'q':13.720},{'Qg':Qg,'Psu':Psu,'E':E,'z':z})
             if len(karr) > 2:
                 if len(tempresult)==0 or tempresult['pile']>karr['pile']:
                     tempresult = karr
             z += 1.1
       
        
        if len(tempresult)==0:
            print("无结果")
        else:
            #"k="+str(tempresult['k']),
            result = "pile="+str(tempresult['pile']),"n="+str(tempresult['n']),"r="+str(tempresult['r']),"圆心 ("+str(tempresult['p']),str(tempresult['q'])+")","φ="+str(phi/pi*180),"c="+str(c)
            print ("第一个程序结果=",minK['log'])
            print("第一个程序结果=",result)
        
    @staticmethod
    def calc_Psu(z,zc,Npu,Npo,ua,Z0,lbd): #求单桩最大侧土压力(psu)。
        Psu = 0
        Cu = c-2
        Npc = Npu-(Npu-Npo)*math.exp(-lbd*zc/D)
        print("Npc=",Npc)
        if z>=0 and z<zc:
           Psu=(Npu-(Npu-Npo)*math.exp(-lbd*z/D))*Cu*D
        elif z>=zc and z<=Z0:
           Psu=(Npu-(Npu-Npc)*math.exp(-lbd*ua*(z-zc)/D))*Cu*D
        elif z>Z0 and z<=L2:
           Psu = -(Npu-(Npu-Npo)*math.exp(-lbd*z/D))**Cu*D
        return Psu
        
    @staticmethod
    def calc_FS_front_pile(Psu,Frs,Fd,E,r,q,p,z):#计算桩前土体的稳定性。
        L0=p-15
        zy=7-q+math.sqrt(r**2-(25-p)**2)
        x=sympy.symbols('z')
        fs= Frs*r/(Fd*r+E*sympy.integrate((z+L0)*Psu*z,(x,0,zy)))
       #print("fs=",fs)
        return fs
        
    @staticmethod
    def calc_FS(Frs,Fd,Q0):
        fs = (Frs+Q0)/Fd
        return fs


class Calc:
    def calc_ks(self,b,r,pi,fai,a,c,is_dx_left,is_use_test_data,ts_data,calc2_values):
        f1 = 0#抗滑力
        f2 = 0#下滑力
        u = 0 #
        #c = 15#粘聚力
        z = γ #图层参数
        hi= 0
        temp = {'k':-1,'p':-1,'q':-1,'n':0,'pile':-1,'result':False}
        increse = 1.5199#此处更改精度
        #圆心坐标范围
        Ox = {'mx':-15,'lx':15}
        Oy = {'my':30,'ly':50}

#        Ox = {'mx':-10,'lx':10}
#        Oy = {'my':10,'ly':15}
       
        p = Ox['mx']  #-15-15
        d_left = is_dx_left
        d_posx = 0
        n=0  #土条个数
        miny = Oy['my']
        con = 51.96
     #   print(con)
        while p<=Ox['lx']:
            if is_use_test_data:
               p=ts_data['p']
            q = Oy['my']
            while q<=Oy['ly']:
                if is_use_test_data:
                   q=ts_data['q']
                if abs(r)<abs(miny-q) or r<q or q-miny==0: #判断条件
                    q+=increse
                    continue
                if (math.sqrt(r**2-(miny-q)**2)+p)<con: #判断条件
                   q+=increse
                   continue
                if d_left:#此处代码不运行
                   if math.sqrt(r**2-q**2)+p>0: #判断条件
                      q+=increse
                      continue
                   d_posx=-math.sqrt(r**2-q**2)+p #D点坐标
                   n = math.ceil((math.sqrt(math.pow(r,2)+math.pow(miny-q,2))+math.sqrt(math.pow(r,2)-math.pow(q,2)))/b)
                else:
                    if p-math.sqrt(r**2-q**2)>0:#判断条件
                       q+=increse
                       continue
                    d_posx=-math.sqrt(r**2-q**2)+p #D点坐标
                    n = math.ceil((math.sqrt(math.pow(r,2)-math.pow(miny-q,2))+math.sqrt(math.pow(r,2)-math.pow(q,2)))/b)
                i=1
                f1 = 0
                f2 = 0
                theta = 0 #既是θ
                while i<n:
                    #土条横坐标
                    xi = -math.sqrt(r**2-q**2)+p+(i/(2*n))*(math.sqrt(r**2-(miny-q)**2)+math.sqrt(r**2-q**2))
                    #求θi值
                    #当D点与土条均在O点左侧时，
                    if d_posx<p and xi<p:
                       theta=math.atan(math.sqrt(r**2-q**2)/q)-(i/n)*(math.atan(math.sqrt(r**2-(miny-q)**2)/(q-miny))+math.atan(math.sqrt(r**2-q**2)/q))
                    #当D点在O点左侧，土条在O点右侧时，
                    elif d_posx<p and xi>p:
                         theta=(i/n)*(math.atan(math.sqrt(r**2-(miny-q)**2)/(q-miny))+math.atan(math.sqrt(r**2-q**2)/q))-math.atan(math.sqrt(r**2-q**2)/q)
                    #当D点在O点右侧时，
                    else:
                        theta=(i/n)*(math.atan(math.sqrt(r**2-(miny-q)**2)/(q-miny))-math.atan(math.sqrt(r**2-q**2)/q))+math.atan(math.sqrt(r**2-q**2)/q)
                    #print("θi=",θi)"""
                    """if xi<p:
                    #if isNeg:
                        x=p+r*math.cos(3*pi/2-θi)
                        y=q+r*math.sin(3*pi/2-θi)
                    else:
                        x=p+r*math.cos(3*pi/2+θi)
                        y=q+r*math.sin(3*pi/2+θi)"""
                   
                    if xi>=p:
                        flag = True
                    else:
                        flag = False
                    x = xi
                    if x>=con:
                        if flag:
                            hi=miny-q-r*math.sin(3*pi/2+theta)
                        else:
                            hi=miny-q-r*math.sin(3*pi/2-theta)
                    elif x>=0 and x<con:
                        if flag:
                            hi=(p+r*math.cos(3*pi/2+theta))*math.tan(a)-q-r*math.sin(3*pi/2+theta)
                        else:
                            hi=(p+r*math.cos(3*pi/2-theta))*math.tan(a)-q-r*math.sin(3*pi/2-theta)
                    elif x<0:
                        if flag:
                            hi=-q-r*math.sin(3*pi/2+theta)
                        else:
                            hi=-q-r*math.sin(3*pi/2-theta)
                            
                    l = b/math.cos(theta) #土条长度
                    fw1 = b*hi*z
                    f1 += c*l+(fw1*math.cos(theta)-u*l)*math.tan(fai)
                    f2 += fw1*math.sin(theta)
                    i+=1
                
                if f2 == 0:
                    #print("无意义")
                    q+=increse
                    continue
                k=f1/f2
                Frs = f1
                Fd = f2
                Qg = calc2_values['Qg']
                Psu = calc2_values['Psu']
                E = calc2_values['E']
                z = calc2_values['z']
                FS = Calc2.calc_FS(Frs,Fd,Qg)
                FS_front_pile = Calc2.calc_FS_front_pile(Psu,Frs,Fd,E,r,q,p,z)
             
               # print("r=",r,"p=",p,"q=",q,"n=",n,"k=",k)
                if k>=1 and FS_front_pile>=1 and FS>=1:
                   print("k=",k,"FS_frontpile=",FS_front_pile)
                   if temp['pile'] == -1 or FS_front_pile<temp['pile']:
                       temp['pile']=FS_front_pile
                       temp['k']=k
                       temp['p']=p
                       temp['q']=q
                       temp['n']=n
                       temp['result']=True
                q+=increse
                if is_use_test_data:
                   break
            p+=increse
            if is_use_test_data:
               break
        return temp
        
    def random_r_qp(self,base_data,is_dx_left,is_use_test_data,ts_data,calc2_values):
        fai = base_data['fai'] #φ 30.0/180.0*pi #内摩擦角
       # a = 30.0/180*pi #坡度
       # b = 0.51 #土条宽度

       #  h = 30 #坡高
        r = 0.5*h #q-4h,r>q
        c = base_data['c'] ##粘聚力
        max_r=4*h
        mink = -1
        tempr = r
        rekarr = {}
        while r<=2.5*h:#半径0-4*h
            #print("r=",r)
            if is_use_test_data:
               r=ts_data['r']
            karr=self.calc_ks(b,r,pi,fai,a,c,is_dx_left,is_use_test_data,ts_data,calc2_values)
            r+=2.5
            if is_use_test_data:
               break
           # break
            result = karr['result']
            if result == True:
                karr['r']=r
                if len(rekarr) == 0:
                   rekarr = karr
                elif rekarr['pile']>karr['pile']:
                   rekarr = karr
                
        return rekarr
           
Calc2.main()
