# -*- coding: utf-8 -*
# -*- coding: cp936 -*-
import math
pi = math.pi
class Calck:
    def calc_ks(self,b,r,pi,fai,a,c,is_dx_left,is_use_test_data,ts_data,lzcon):
        f1 = 0#抗滑力
        f2 = 0#下滑力
        u = 0 #
        #c = 15#粘聚力
        z = 18.5 #图层参数
        hi= 0
        temp = {'k':-1,'p':-1,'q':-1,'n':0}
        increse = 0.5199#此处更改精度
        #圆心坐标范围
        Ox = {'mx':-15,'lx':15}
        Oy = {'my':30,'ly':50}

        p = Ox['mx']  #-15-15
        d_left = is_dx_left
        d_posx = 0
        n=0  #土条个数
        miny = Oy['my']
        con = 51.96
     #   print(con)
        while p<=Ox['lx']:
            if is_use_test_data:
               p=ts_data['p']
            q = Oy['my']
            while q<=Oy['ly']:
                if is_use_test_data:
                   q=ts_data['q']
                if lzcon == True:
                   if r<math.sqrt((25-p)**2+(-5-q)**2):
                      q+=increse
                      continue
                if abs(r)<abs(miny-q) or r<q or q-miny==0: #判断条件
                    q+=increse
                    continue
                if (math.sqrt(r**2-(miny-q)**2)+p)<con: #判断条件
                   q+=increse
                   continue
                if d_left:#此处代码不运行
                   if math.sqrt(r**2-q**2)+p>0: #判断条件
                      q+=increse
                      continue
                   d_posx=-math.sqrt(r**2-q**2)+p #D点坐标
                   n = math.ceil((math.sqrt(math.pow(r,2)+math.pow(miny-q,2))+math.sqrt(math.pow(r,2)-math.pow(q,2)))/b)
                else:
                    if p-math.sqrt(r**2-q**2)>0:#判断条件
                       q+=increse
                       continue
                    d_posx=-math.sqrt(r**2-q**2)+p #D点坐标
                    n = math.ceil((math.sqrt(math.pow(r,2)-math.pow(miny-q,2))+math.sqrt(math.pow(r,2)-math.pow(q,2)))/b)
                i=1
                f1 = 0
                f2 = 0
                theta = 0 #既是θ
                while i<n:
                    #土条横坐标
                    xi = -math.sqrt(r**2-q**2)+p+(i/(2*n))*(math.sqrt(r**2-(miny-q)**2)+math.sqrt(r**2-q**2))
                    #求θi值
                    #当D点与土条均在O点左侧时，
                    if d_posx<p and xi<p:
                       theta=math.atan(math.sqrt(r**2-q**2)/q)-(i/n)*(math.atan(math.sqrt(r**2-(miny-q)**2)/(q-miny))+math.atan(math.sqrt(r**2-q**2)/q))
                    #当D点在O点左侧，土条在O点右侧时，
                    elif d_posx<p and xi>p:
                         theta=(i/n)*(math.atan(math.sqrt(r**2-(miny-q)**2)/(q-miny))+math.atan(math.sqrt(r**2-q**2)/q))-math.atan(math.sqrt(r**2-q**2)/q)
                    #当D点在O点右侧时，
                    else:
                        theta=(i/n)*(math.atan(math.sqrt(r**2-(miny-q)**2)/(q-miny))-math.atan(math.sqrt(r**2-q**2)/q))+math.atan(math.sqrt(r**2-q**2)/q)
                    #print("θi=",θi)"""
                    """if xi<p:
                    #if isNeg:
                        x=p+r*math.cos(3*pi/2-θi)
                        y=q+r*math.sin(3*pi/2-θi)
                    else:
                        x=p+r*math.cos(3*pi/2+θi)
                        y=q+r*math.sin(3*pi/2+θi)"""
                   
                    if xi>=p:
                        flag = True
                    else:
                        flag = False
                    x = xi
                    if x>=con:
                        if flag:
                            hi=miny-q-r*math.sin(3*pi/2+theta)
                        else:
                            hi=miny-q-r*math.sin(3*pi/2-theta)
                    elif x>=0 and x<con:
                        if flag:
                            hi=(p+r*math.cos(3*pi/2+theta))*math.tan(a)-q-r*math.sin(3*pi/2+theta)
                        else:
                            hi=(p+r*math.cos(3*pi/2-theta))*math.tan(a)-q-r*math.sin(3*pi/2-theta)
                    elif x<0:
                        if flag:
                            hi=-q-r*math.sin(3*pi/2+theta)
                        else:
                            hi=-q-r*math.sin(3*pi/2-theta)
                            
                    l = b/math.cos(theta) #土条长度
                    fw1 = b*hi*z
                    f1 += c*l+(fw1*math.cos(theta)-u*l)*math.tan(fai)
                    f2 += fw1*math.sin(theta)
                    i+=1
                
                if f2 == 0:
                    #print("无意义")
                    q+=increse
                    continue
                k=f1/f2
                #if k>1:
                print("r=",r,"p=",p,"q=",q,"n=",n,"k=",k)
                if temp['k'] == -1 and k>0:
                    temp['k']=k
                    temp['p']=p
                    temp['q']=q
                    temp['n']=n
                elif temp['k']>k and k>0:
                    temp['k']=k
                    temp['p']=p
                    temp['q']=q
                    temp['n']=n
                q+=increse
                if is_use_test_data:
                   break
            p+=increse
            if is_use_test_data:
               break
        return temp#[mink,temp_p,temp_q,n]
        
    def random_r_qp(self,base_data,is_dx_left,is_use_test_data,ts_data,lzcon):
        fai = base_data['fai'] #φ 30.0/180.0*pi #内摩擦角
        a = 30.0/180*pi #坡度
        b = 0.51 #土条宽度

        h = 30 #坡高
        r = 0 #q-4h,r>q
        c = base_data['c'] ##粘聚力
        max_r=4*h
        mink = -1
        tempr = r
        temp_karr = {}
        
        while r<=2*h:#半径0-4*h
            #print("r=",r)
            if is_use_test_data:
               r=ts_data['r']
            karr=self.calc_ks(b,r,pi,fai,a,c,is_dx_left,is_use_test_data,ts_data,lzcon)
            k=karr['k']
            print("r=",r,"k=",k)
            if k==-1:
               r+=0.5
               continue
            if mink == -1:
                mink=k
                tempr=r
                temp_karr=karr
            elif mink > k:
                mink=k
                tempr=r
                temp_karr=karr
            r+=1.5
            if is_use_test_data:
               break
           # break
        if len(temp_karr) < 2:
           return "无结果"
        else:
           log = "k="+str(mink),"n="+str(temp_karr['n']),"r="+str(tempr),"圆心 ("+str(temp_karr['p']),str(temp_karr['q'])+")","φ="+str(fai/pi*180),"c="+str(c)
           return {'k':mink,'log':log}
        
#calc_class = Calc()
#k2 = calc_class.random_r_qp({'fai':18.8/180.0*pi,'c':20},False,False,{'r':13.751,'p':-0.920,'q':13.720})
#print ("指定数据结果",k2)
"""
def calc_test_data():
    calc_class = Calc()
    k2 = calc_class.random_r_qp({'fai':30.0/180.0*pi,'c':15},False,True,{'r':13.751,'p':-0.920,'q':13.720})
    k3 = calc_class.random_r_qp({'fai':30.0/180.0*pi,'c':5},False,True,{'r':15.15,'p':-3.24,'q':14.80})
    k4 = calc_class.random_r_qp({'fai':30.0/180.0*pi,'c':10},False,True,{'r':14.105,'p':-1.72,'q':14.00})
    k5 = calc_class.random_r_qp({'fai':30.0/180.0*pi,'c':20},False,True,{'r':13.56,'p':-0.360,'q':13.5600})
    k6 = calc_class.random_r_qp({'fai':20.0/180.0*pi,'c':20},False,True,{'r':13.56,'p':-0.44,'q':13.5600})

    
    k22 = calc_class.random_r_qp({'fai':30.0/180.0*pi,'c':15},False,False,{'r':13.751,'p':-0.920,'q':13.720})
    k33 = calc_class.random_r_qp({'fai':30.0/180.0*pi,'c':5},False,False,{'r':15.15,'p':-3.24,'q':14.80})
    k44 = calc_class.random_r_qp({'fai':30.0/180.0*pi,'c':10},False,False,{'r':14.105,'p':-1.72,'q':14.00})
    k55 = calc_class.random_r_qp({'fai':30.0/180.0*pi,'c':20},False,False,{'r':13.56,'p':-0.360,'q':13.5600})
    k66 = calc_class.random_r_qp({'fai':20.0/180.0*pi,'c':20},False,False,{'r':13.56,'p':-0.44,'q':13.5600})

    print ("指定数据结果",k2,"\n非指定数据结果",k22,"\n")
    print ("指定数据结果",k3,"\n非指定数据结果",k33,"\n")
    print ("指定数据结果",k4,"\n非指定数据结果",k44,"\n")
    print ("指定数据结果",k5,"\n非指定数据结果",k55,"\n")
    print ("指定数据结果",k6,"\n非指定数据结果",k66,"\n")

print("正在打印测试数据........")
calc_test_data()

while True:
    print("输入'φ','c'以空格号（‘ ’）隔开")
    fai,c = 0,0
    if  sys.version_info.major == 2:
        fai,c = list(map(int, raw_input().split()))
    else:
        fai,c = list(map(int, input().split()))
    print("φ="+str(fai),"c="+str(c))
    print("正在计算数据........")
    k = Calc().random_r_qp({'fai':fai/180.0*pi,'c':c},False,False,{})
    print("计算结果",k)

"""
