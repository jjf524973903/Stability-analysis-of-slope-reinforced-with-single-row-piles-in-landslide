import math
import sympy
from calc_1 import Calck
t= 25
γ = 18.5 #土层参数
c = 20 #黏聚力
phi = 18.8/180*math.pi #内摩擦 θ
b = 0.51 #土条弧长
a = 20*math.pi/180 # 坡度
D_POS ={'x':0,'y':0} #坡脚D为坐标原点
D = 2 #桩直径
D2 = 5 #桩间距
D1 = 3 #桩净距
L1 = 7 #滑面之上桩深
L2 = 13 #滑面之下桩深
L = 20
H = 30 #坡高
pi = math.pi
Nphi = math.pow(math.tan(math.pi/4+phi/2),2)
class Calc2:
    @staticmethod
    def calc_Q(Thetai,z0): #计算上部滑坡推力Q0。
        li=b/math.cos(Thetai)
        Aexp1 = c*D2*math.pow(D2/D1,math.pow(Nphi,1/2)*math.tan(phi)+Nphi-1)
        Aexp2 = 1/(Nphi*math.tan(phi))*(math.exp((D2-D1)/D1*Nphi*math.tan(phi)*math.tan(math.pi/8+phi/4))-2*math.sqrt(Nphi)*math.tan(phi)-1)
        Aexp3 = (2*math.tan(phi)+2*math.sqrt(Nphi)+math.pow(Nphi,-1/2))/(math.sqrt(Nphi)*math.tan(phi)+Nphi-1)
        A = Aexp1*(Aexp2+Aexp3)
        B = -c*(D2*(2*math.tan(phi)+2*math.sqrt(Nphi)+math.pow(Nphi,-1/2))/(math.sqrt(Nphi)*math.tan(phi)+Nphi-1)-2*D1*math.pow(Nphi,-1/2))
        Cexp1 = D2*math.pow(D2/D1,math.sqrt(Nphi)*math.tan(phi)+Nphi-1)
        Cexp2 = math.exp((D2-D1)/D1*Nphi*math.tan(phi)*math.tan(math.pi/8+phi/4))
#        C = γ*z/Nphi*(Cexp1*Cexp2-D1)
#        q = A+B+C
        z=sympy.symbols('z')
        Q = sympy.integrate(A+B+γ*z/Nphi*(Cexp1*Cexp2-D1),(z,0,L1))
        return Q
        
    @staticmethod
    def main(): #确定支护桩转动中心点位置z0。
        d = 0 # 临坡距
        zc= D*(8.5-9*math.log10(8-d/D))#D*(8.5-10*math.log(8-d/D,10))
        ψ = 0.5 # 桩土粘结系数
        delta = 1/math.sin(ψ)
        print("zc=",zc)
        Npu=math.pi+2*delta+2*math.cos(delta)+4*(math.cos(delta/2)+math.sin(delta/2))
        lbd=0.55-0.15*ψ # λ
        Npo = 2+1.5*ψ
       
        ua = 1-math.sin(a)*(1+math.sin(a))/2
        print("Npo=",Npo,"\nNpu=",Npu,"\nλ=",lbd)
        S1 = γ*D*(Npu-Npo)*math.tan(phi)/lbd
        S2 = D/lbd+c/(γ*math.tan(phi))
        S3 = D/(lbd*ua)+c/(γ*math.tan(phi))
       # E = 1-2*math.pow(1-(D2/D)/(2*D2/D*math.tan(phi)+1),2)
        E = 1-5*(1-0.6*math.pow(D2/D,0.3))*(1-math.pow(6,-0.09))
        
        print("\nS1=",S1,"\nS2=",S2,"\nS3=",S3,"\nE=",E,"\nua=",ua)
        
        n1 = 2*γ*Npu*math.tan(phi)+lbd*S1/D*(lbd*(zc+S2)/D-2)*math.exp(-lbd*zc/D)+lbd*S1/D*(lbd*ua/D-2)
        n2 = 2*Npu*(γ*math.tan(phi)+c)-S1*(1-lbd/D*(zc+S2))*math.exp(-lbd*zc/D)-S1/ua*(1-lbd*ua/D*(zc+S3))
     
        z_range= {'min':-5,'max':15}
        z = z_range['min']
        total_res = []
        
        Qg = Calc2.calc_Q(phi,7)
        print("Qg=",Qg)
        #return
        n3 = Npu*(γ*math.tan(phi)*(zc**2-(L2**2)/2)+2*c*zc-c*L2)+S1*math.exp(-lbd*zc/D)*(2*zc+S2-L2)-Qg/(2*E*D)-S1*S2
        print("\nn1=",n1,"\nn2=",n2,"\nn3=",n3)
        tempresult = {}
        
        if (n2**2-4*n1*n3)>0:
            Z0 = (2*zc*n1-n2+math.sqrt(n2**2-4*n1*n3))/(2*n1)
        else:
            return
            
        minK = {}
        calcK=Calck()
        minK=calcK.random_r_qp({'fai':phi,'c':c},False,False,{'r':13.751,'p':-0.920,'q':13.720},True)
        print("mini k=",minK['log'])
        if minK['k']<1:
           print("终止，最小k值不满足大于1")
           return

        if L2<=Z0:
           print("L2=",L2,"Z0=",Z0,"终止，L2<=Z0")
           return
        if Z0<zc:
           print("终止，Z0<zc")
           return
            
        while z < z_range['max']:
             print("******** 求pile计算进度 = ",str(round(100*(z+5)/20.0,2))+"%","***********")
             Psu = Calc2.calc_Psu(z,zc,Npu,Npo,ua,Z0,lbd)
             print ("Z0=",Z0,"\nz=",z,"\npsu=",Psu)
             if Psu == -1:
                z += 1.1
                continue
             CALC_K=Calc()
             karr = CALC_K.random_r_qp({'fai':phi,'c':c},False,False,{'r':13.751,'p':-0.920,'q':13.720},{'Qg':Qg,'Psu':Psu,'E':E,'z':z})
             if len(karr) > 2:
                 if len(tempresult)==0 or tempresult['pile']>karr['pile']:
                     tempresult = karr
             z += 1.1
       
        
        if len(tempresult)==0:
            print("无结果")
        else:
            #"k="+str(tempresult['k']),
            result = "pile="+str(tempresult['pile']),"n="+str(tempresult['n']),"r="+str(tempresult['r']),"圆心 ("+str(tempresult['p']),str(tempresult['q'])+")","φ="+str(phi/pi*180),"c="+str(c),"Frs="+str(tempresult['frs']),"Fd="+str(tempresult['fd'])
            print ("第一个程序结果=",minK['log'])
            print("第二个程序结果=",result)
        
    @staticmethod
    def calc_Psu(z,zc,Npu,Npo,ua,Z0,lbd): #求单桩最大侧土压力(psu)。
        Psu = -1
        Cu = c-2
        Npc = Npu-(Npu-Npo)*math.exp(-lbd*zc/D)
        print("Npc=",Npc)
        if z>=0 and z<zc:
           Psu=(Npu-(Npu-Npo)*math.exp(-lbd*z/D))*Cu*D
        elif z>=zc and z<=Z0:
           Psu=(Npu-(Npu-Npc)*math.exp(-lbd*ua*(z-zc)/D))*Cu*D
        elif z>Z0 and z<=L2:
           Psu = -(Npu-(Npu-Npo)*math.exp(-lbd*z/D))*Cu*D
        return Psu
        
    @staticmethod
    def calc_FS_front_pile(Psu,Frs,Fd,E,r,q,p):#计算桩前土体的稳定性。
        L0=p-t*math.tan(a)
        zy=t*math.tan(a)-7.42-q+math.sqrt(r**2-(t-p)**2)
        z=sympy.symbols('z')
        fs= Frs*r/(Fd*r+E*sympy.integrate((z+L0)*Psu*z,(z,0,zy)))
       # print("zzzzzzzzzzzzz=",zy)
       #print("fs=",fs)
        return fs
        
    @staticmethod
    def calc_FS(Frs,Fd,Q0):
        fs = (Frs+Q0)/Fd
        return fs


class Calc:
    def calc_ks(self,b,r,pi,fai,a,c,is_dx_left,is_use_test_data,ts_data,calc2_values):
        f1 = 0#抗滑力
        f2 = 0#下滑力
        u = 0 #
        #c = 15#粘聚力
        z = γ #图层参数
        hi= 0
        temp = {'k':-1,'p':-1,'q':-1,'n':0,'pile':-1,'result':False}
        increse = 1.5199#此处更改精度
        #圆心坐标范围
        Ox = {'mx':-10,'lx':10}
        Oy = {'my':30,'ly':60}

#        Ox = {'mx':-10,'lx':10}
#        Oy = {'my':10,'ly':15}
       
        p = Ox['mx']  #-15-15
        d_left = is_dx_left
        d_posx = 0
        n=0  #土条个数
        miny = Oy['my']
        con = H/math.tan(a)
     #   print(con)
        while p<=Ox['lx']:
            if is_use_test_data:
               p=ts_data['p']
            q = Oy['my']
            while q<=Oy['ly']:
                if is_use_test_data:
                   q=ts_data['q']
                if r**2-(t-p)**2<0 or r**2-q**2<0: #判断条件
                    q+=increse
                    continue
                if t*math.tan(a)<q-math.sqrt(r**2-(t-p)**2) or q-math.sqrt(r**2-(t-p)**2)<t*math.tan(a)-L: #判断条件
                   q+=increse
                   continue
                if p - math.sqrt(r**2-q**2)>=0 or p - math.sqrt(r**2-q**2)<=-15:
                   q+=increse
                   continue
                if math.sqrt((t-p)**2+(t*math.tan(a)-L-q)**2)<r or r<math.sqrt((t-p)**2+(t*math.tan(a)-q)**2): #判断条件
                   q+=increse
                   continue
                if d_left:#此处代码不运行
                   if math.sqrt(r**2-q**2)-p>0: #判断条件
                      q+=increse
                      continue
                else:
                    d_posx=-math.sqrt(r**2-q**2)+ p #D点坐标
                    n = math.ceil((t+p+math.sqrt(r**2-q**2))/b)
                   # print("n=",n)
                i=1
                f1 = 0
                f2 = 0
                theta = 0 #既是θ
                if t-p<=0:
                   q+=increse
                   continue
                while i<n:
                    #土条横坐标
                    xi = -math.sqrt(r**2-q**2)+p+i/(1*n)*(t+p+math.sqrt(r**2-q**2))-0.25
                    if xi<p-math.sqrt(r**2-q**2) or xi>t:
                       q+=increse
                       break
                    #求θi值
                    #当D点与土条均在O点左侧时，
                    if xi<p:
                       theta=math.atan(math.sqrt(r**2-q**2)/q)-(i/n)*(math.atan((t-p)/math.sqrt(r**2-(t-p)**2))+math.atan(math.sqrt(r**2-q**2)/q))
        
                    elif xi>=p:
                         theta=-math.atan(math.sqrt(r**2-q**2)/q)+i/n*(math.atan((t-p)/math.sqrt(r**2-(t-p)**2))+math.atan(math.sqrt(r**2-q**2)/q))
                    else:
                         theta=math.atan(sqrt(r**2-q**2)/q)+i/n*(math.atan((t-p)/math.sqrt(r**2-(t-p)**2))-math.atan(math.sqrt(r**2-q**2)/q))       
                    #theta=abs(theta)
                    if xi>=0 and xi<t and xi>=p:
                       hi = (p+r*math.cos(3*pi/2+theta))*math.tan(a)-q-r*math.sin(3*pi/2+theta)
                    elif xi>=0 and xi<t and xi<p:
                       hi = (p+r*math.cos(3*pi/2-theta))*math.tan(a)-q-r*math.sin(3*pi/2-theta)
                    elif xi<0 and xi>=p:
                       hi = -q-r*math.sin(3*pi/2+theta)
                    elif xi<0 and xi<p:
                       hi = -q-r*math.sin(3*pi/2-theta)
                   
                    l = b/math.cos(theta) #土条长度
                    fw1 = b*hi*z
                    f1 += c*l+(fw1*math.cos(theta)-u*l)*math.tan(fai)
                    f2 += fw1*math.sin(theta)
                    i+=1
#                    if f2<0 or f1<0:
#                       print("f1=",f1,"\nf2=",f2,"\nb=",b,"\nhi=",hi,"\ntheta=",theta,"\nr=",r,"\ni=",i,"\nq=",q,"\np=",p,"\nxi=",xi,"\nn=",n,"\nl=",l,"\nz=",z)
#                       return
                
                if f2 == 0 or f2<0 or f1<0 or hi<0:
                    #print("无意义")
                    q+=increse
                    continue
                k=f1/f2
                Frs = f1
                Fd = f2
              #  print("FD=",Fd,"FRS=",Frs)
                
                Qg = calc2_values['Qg']
                Psu = calc2_values['Psu']
                E = calc2_values['E']
                #z = calc2_values['z']
               # FS = Calc2.calc_FS(Frs,Fd,Qg)
                FS_front_pile = Calc2.calc_FS_front_pile(Psu,Frs,Fd,E,r,q,p)
             
                #print("r=",r,"p=",p,"q=",q,"n=",n,"k=",k)
             
                #if FS_front_pile>=1:
                   #print("k=",k,"FS_frontpile=",FS_front_pile)
                  # print("FS_frontpile=",FS_front_pile)
                if FS_front_pile>0 and Psu>0:
                    if temp['pile'] == -1 or FS_front_pile<temp['pile']:
                       temp['pile']=FS_front_pile
                       temp['k']=k
                       temp['p']=p
                       temp['q']=q
                       temp['n']=n
                       temp['fd']=Fd
                       temp['frs']=Frs
                       temp['result']=True
#                       print("\npsu=",Psu,"\nfrs=",Frs,"\nfd=",Fd,"\nE=",E,"\nr=",r,"\nq=",q,"\np=",p,"\npile=",FS_front_pile)
                       #return
                #else:
                    #print("pile=",FS_front_pile)
                q+=increse
                if is_use_test_data:
                   break
            p+=increse
            if is_use_test_data:
               break
        return temp
        
    def random_r_qp(self,base_data,is_dx_left,is_use_test_data,ts_data,calc2_values):
        fai = base_data['fai'] #φ 30.0/180.0*pi #内摩擦角
        r = 0 #q-4h,r>q
        c = base_data['c'] ##粘聚力
        mink = -1
        tempr = r
        rekarr = {}
        add=0
        while r<=1.3*H+add and r<3*H:#半径0-4*h
            #print("r=",r)
            if is_use_test_data:
               r=ts_data['r']
            karr=self.calc_ks(b,r,pi,fai,a,c,is_dx_left,is_use_test_data,ts_data,calc2_values)
          
            if is_use_test_data:
               break
           # break
            result = karr['result']
            if result == True:
                karr['r']=r
                if len(rekarr) == 0:
                   rekarr = karr
                elif rekarr['pile']>karr['pile']:
                    rekarr = karr
            r+=1
            if r>1.2*H+add and len(rekarr)==0:#扩大搜索半径
               add+=0.2*H
        return rekarr
           
Calc2.main()
